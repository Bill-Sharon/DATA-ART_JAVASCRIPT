export interface EventData {
  year: number;
  title: string;
  description: string;
  imageURL: string;
  category: string;
}
