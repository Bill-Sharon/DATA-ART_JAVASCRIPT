import { EventData } from "./types.js";
import { openModal } from "./modal.js";

export function renderEvents(events: EventData[]) {
  const timeline = document.getElementById("timeline");
  if (!timeline) return;

  events.forEach(ev => {
    const eventEl = document.createElement("div");
    eventEl.classList.add("event");

    eventEl.innerHTML = `
      <div class="circle"></div>
      <div class="card">
        <img src="${ev.imageURL}" alt="${ev.title}">
        <h3>${ev.year} - ${ev.title}</h3>
        <p>${ev.description}</p>
      </div>
    `;

    eventEl.querySelector(".card")?.addEventListener("click", () => openModal(ev));
    timeline.appendChild(eventEl);
  });
}
