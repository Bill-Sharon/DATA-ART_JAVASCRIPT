# F1 Timeline — Vite + React + TypeScript

A clean React implementation of the timeline UI with:
- `<Header>` (logo + theme switch)
- `<Timeline>` that maps event data and renders `<EventMarker>`
- `<EventMarker>` for each year/title dot
- `<EventModal>` using a React Portal
- Optional `<FilterPanel>` (skeleton for future filters/bookmarks)
- State with hooks to load data and control modal visibility
- Styling with CSS Modules

## Dev Quickstart

```bash
npm install
npm run dev
```

## File Highlights
- Event data: `src/data/events.json`
- Types: `src/types.ts`
- Theme hook: `src/hooks/useTheme.ts`
