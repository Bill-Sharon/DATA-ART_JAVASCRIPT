import { useRef } from 'react'
import styles from '@/styles/Timeline.module.css'
import EventMarker from './EventMarker'
import type { TimelineEvent } from '@/types'

interface Props {
  events: TimelineEvent[]
  onSelect: (ev: TimelineEvent, trigger: HTMLButtonElement | null) => void
  activeId?: string | null
}

export default function Timeline({ events, onSelect, activeId }: Props) {
  const refs = useRef<(HTMLButtonElement | null)[]>([])
  const ordered = [...events].sort((a, b) => a.year - b.year)

  function handleKey(e: React.KeyboardEvent<HTMLDivElement>) {
    const currentIndex = refs.current.findIndex((el) => el === document.activeElement)
    if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
      e.preventDefault()
      const next = refs.current[(currentIndex + 1) % refs.current.length]
      next?.focus()
    } else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
      e.preventDefault()
      const prev = refs.current[(currentIndex - 1 + refs.current.length) % refs.current.length]
      prev?.focus()
    }
  }

  return (
    <div
      className={styles.timelineWrapper}
      role="list"
      aria-label="F1 Timeline of events"
      onKeyDown={handleKey}
    >
      <div className={styles.timeline}>
        {ordered.map((ev, i) => (
          <EventMarker
            key={ev.id}
            ref={(el) => (refs.current[i] = el)}
            event={ev}
            onClick={() => onSelect(ev, refs.current[i])}
            isActive={activeId === ev.id}
          />
        ))}
      </div>
    </div>
  )
}
