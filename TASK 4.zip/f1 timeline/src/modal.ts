import { EventData } from "./types.js";

const modal = document.getElementById("modal") as HTMLDivElement;
const closeModalBtn = document.getElementById("closeModal") as HTMLSpanElement;

const modalImage = document.getElementById("modalImage") as HTMLImageElement;
const modalTitle = document.getElementById("modalTitle") as HTMLHeadingElement;
const modalYear = document.getElementById("modalYear") as HTMLParagraphElement;
const modalDescription = document.getElementById("modalDescription") as HTMLParagraphElement;
const modalCategory = document.getElementById("modalCategory") as HTMLParagraphElement;

export function openModal(ev: EventData) {
  modalImage.src = ev.imageURL;
  modalTitle.textContent = ev.title;
  modalYear.textContent = `Year: ${ev.year}`;
  modalDescription.textContent = ev.description;
  modalCategory.textContent = `Category: ${ev.category}`;
  modal.style.display = "flex";
}

export function initModal() {
  closeModalBtn.addEventListener("click", () => modal.style.display = "none");
  window.addEventListener("click", e => {
    if (e.target === modal) modal.style.display = "none";
  });
}
