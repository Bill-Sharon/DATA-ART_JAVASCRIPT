import styles from '@/styles/EventMarker.module.css'
import type { TimelineEvent } from '@/types'

interface Props {
  event: TimelineEvent
  onClick: () => void
}

export default function EventMarker({ event, onClick }: Props) {
  return (
    <button className={styles.marker} onClick={onClick} title={event.title}>
      <span className={styles.dot} />
      <span className={styles.meta}>
        <span className={styles.year}>{event.year}</span>
        <span className={styles.title}>{event.title}</span>
      </span>
    </button>
  )
}
