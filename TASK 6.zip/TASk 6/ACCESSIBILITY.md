# Accessibility Improvements

- Modal uses `role="dialog"`, `aria-modal="true"`, labelled by title and description.
- Focus trapped inside modal, ESC closes it, and focus returns to triggering element.
- Timeline markers have `aria-label` with year+title, and `aria-current="true"` on active.
- Keyboard navigation: Tab and Arrow keys cycle through markers.
- Verified sufficient colour contrast (meets WCAG AA).
- Header buttons have `aria-label` and clear titles.
