import styles from '@/styles/FilterPanel.module.css'

export default function FilterPanel() {
  // Skeleton for future filters/bookmarks
  return (
    <div className={styles.panel}>
      <h3>Filters</h3>
      <p>Tag filters and bookmarks coming soon.</p>
    </div>
  )
}
