import { useEffect } from 'react'
import { createPortal } from 'react-dom'
import styles from '@/styles/EventModal.module.css'
import type { TimelineEvent } from '@/types'

interface Props {
  event: TimelineEvent | null
  onClose: () => void
}

function ModalContent({ event, onClose }: Props) {
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [onClose])

  if (!event) return null

  return (
    <div className={styles.backdrop} onClick={onClose} role="dialog" aria-modal="true">
      <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
        <header className={styles.header}>
          <h2>{event.year} — {event.title}</h2>
          <button className={styles.close} onClick={onClose} aria-label="Close">✕</button>
        </header>
        <div className={styles.body}>
          {event.image && (
            <img className={styles.image} src={event.image} alt={event.title} />
          )}
          <p className={styles.desc}>{event.description}</p>
          {event.link && (
            <p className={styles.linkWrap}>
              <a href={event.link} target="_blank" rel="noreferrer">Learn more ↗</a>
            </p>
          )}
        </div>
      </div>
    </div>
  )
}

export default function EventModal(props: Props) {
  const root = document.getElementById('modal-root')
  if (!root) return null
  return createPortal(<ModalContent {...props} />, root)
}
