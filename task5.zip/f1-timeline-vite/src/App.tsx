import { useEffect, useState } from 'react'
import Header from './components/Header'
import Timeline from './components/Timeline'
import EventModal from './components/EventModal'
import FilterPanel from './components/FilterPanel'
import type { TimelineEvent } from './types'
import styles from './styles/App.module.css'

function App() {
  const [events, setEvents] = useState<TimelineEvent[]>([])
  const [activeEvent, setActiveEvent] = useState<TimelineEvent | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let isMounted = true
    // Simulate async load (you could fetch from an API)
    import('./data/events.json').then((mod) => {
      if (isMounted) {
        setEvents(mod.default)
        setLoading(false)
      }
    })
    return () => { isMounted = false }
  }, [])

  return (
    <div className={styles.app}>
      <Header />
      <main className={styles.main}>
        <aside className={styles.sidebar}>
          <FilterPanel />
        </aside>
        <section className={styles.content}>
          {loading ? (
            <div className={styles.loading}>Loading timeline…</div>
          ) : (
            <Timeline events={events} onSelect={setActiveEvent} />
          )}
        </section>
      </main>

      <EventModal
        event={activeEvent}
        onClose={() => setActiveEvent(null)}
      />
    </div>
  )
}

export default App
