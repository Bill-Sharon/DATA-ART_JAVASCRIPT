import { useTheme } from '@/hooks/useTheme'
import styles from '@/styles/Header.module.css'

export default function Header() {
  const { theme, toggleTheme } = useTheme()
  return (
    <header className={styles.header}>
      <div className={styles.brand}>
        <span className={styles.logo}>🏁</span>
        <h1 className={styles.title}>F1 Timeline</h1>
      </div>
      <button
        className={styles.themeToggle}
        onClick={toggleTheme}
        aria-label="Toggle theme"
        title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
      >
        {theme === 'dark' ? '🌙' : '☀️'}
      </button>
    </header>
  )
}
