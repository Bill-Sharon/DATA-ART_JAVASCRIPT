document.addEventListener("DOMContentLoaded", () => {
  const timeline = document.getElementById("timeline");
  const modal = document.getElementById("modal");
  const closeModalBtn = document.getElementById("closeModal");

  const modalImage = document.getElementById("modalImage");
  const modalTitle = document.getElementById("modalTitle");
  const modalYear = document.getElementById("modalYear");
  const modalDescription = document.getElementById("modalDescription");
  const modalCategory = document.getElementById("modalCategory");

  fetch("events.json")
    .then(res => res.json())
    .then(events => {
      events.forEach(event => {
        const eventEl = document.createElement("div");
        eventEl.classList.add("event");

        eventEl.innerHTML = `
          <div class="circle"></div>
          <div class="card">
            <img src="${event.imageURL}" alt="${event.title}">
            <h3>${event.year} - ${event.title}</h3>
            <p>${event.description}</p>
          </div>
        `;

        eventEl.querySelector(".card").addEventListener("click", () => {
          modalImage.src = event.imageURL;
          modalTitle.textContent = event.title;
          modalYear.textContent = `Year: ${event.year}`;
          modalDescription.textContent = event.description;
          modalCategory.textContent = `Category: ${event.category}`;
          modal.style.display = "flex";
        });

        timeline.appendChild(eventEl);
      });
    })
    .catch(err => console.error("Error loading events:", err));

  closeModalBtn.addEventListener("click", () => {
    modal.style.display = "none";
  });

  window.addEventListener("click", (e) => {
    if (e.target === modal) {
      modal.style.display = "none";
    }
  });
});
