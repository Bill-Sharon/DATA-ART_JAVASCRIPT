import styles from '@/styles/Timeline.module.css'
import EventMarker from './EventMarker'
import type { TimelineEvent } from '@/types'

interface Props {
  events: TimelineEvent[]
  onSelect: (ev: TimelineEvent) => void
}

export default function Timeline({ events, onSelect }: Props) {
  // Sort by year asc
  const ordered = [...events].sort((a, b) => a.year - b.year)

  return (
    <div className={styles.timelineWrapper}>
      <div className={styles.timeline}>
        {ordered.map((ev) => (
          <EventMarker key={ev.id} event={ev} onClick={() => onSelect(ev)} />
        ))}
      </div>
    </div>
  )
}
