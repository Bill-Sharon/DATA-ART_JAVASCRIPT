import { useEffect, useRef } from 'react'
import { createPortal } from 'react-dom'
import styles from '@/styles/EventModal.module.css'
import type { TimelineEvent } from '@/types'

interface Props {
  event: TimelineEvent | null
  onClose: () => void
  triggerRef?: React.RefObject<HTMLButtonElement | null>
}

function useFocusTrap(containerRef: React.RefObject<HTMLDivElement>, isOpen: boolean, onClose: () => void, trigger?: HTMLElement | null) {
  useEffect(() => {
    if (!isOpen) return
    const container = containerRef.current
    if (!container) return
    const focusable = container.querySelectorAll<HTMLElement>(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    )
    const first = focusable[0]
    const last = focusable[focusable.length - 1]

    function handleKey(e: KeyboardEvent) {
      if (e.key === 'Tab') {
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault(); last.focus()
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault(); first.focus()
        }
      } else if (e.key === 'Escape') {
        onClose()
      }
    }

    document.addEventListener('keydown', handleKey)
    first?.focus()
    return () => {
      document.removeEventListener('keydown', handleKey)
      trigger?.focus()
    }
  }, [isOpen, containerRef, onClose, trigger])
}

function ModalContent({ event, onClose, triggerRef }: Props) {
  const dialogRef = useRef<HTMLDivElement>(null)
  const open = !!event
  useFocusTrap(dialogRef, open, onClose, triggerRef?.current || undefined)
  if (!event) return null

  return (
    <div className={styles.backdrop} onClick={onClose}>
      <div
        className={styles.modal}
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        onClick={(e) => e.stopPropagation()}
      >
        <header className={styles.header}>
          <h2 id="modal-title">{event.year} — {event.title}</h2>
          <button className={styles.close} onClick={onClose} aria-label="Close">✕</button>
        </header>
        <div className={styles.body} id="modal-desc">
          {event.image && <img className={styles.image} src={event.image} alt={event.title} />}
          <p className={styles.desc}>{event.description}</p>
          {event.link && <p className={styles.linkWrap}>
            <a href={event.link} target="_blank" rel="noreferrer">Learn more ↗</a>
          </p>}
        </div>
      </div>
    </div>
  )
}

export default function EventModal(props: Props) {
  const root = document.getElementById('modal-root')
  if (!root) return null
  return createPortal(<ModalContent {...props} />, root)
}
