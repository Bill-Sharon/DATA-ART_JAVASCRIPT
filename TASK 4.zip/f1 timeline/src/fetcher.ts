import { EventData } from "./types.js";

export async function fetchEvents(url: string): Promise<EventData[]> {
  const res = await fetch(url);
  return await res.json() as EventData[];
}
