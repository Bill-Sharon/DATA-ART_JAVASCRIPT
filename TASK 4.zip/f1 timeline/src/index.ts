import { fetchEvents } from "./fetcher.js";
import { renderEvents } from "./renderer.js";
import { initModal } from "./modal.js";

document.addEventListener("DOMContentLoaded", async () => {
  initModal();
  const events = await fetchEvents("events.json");
  renderEvents(events);
});
