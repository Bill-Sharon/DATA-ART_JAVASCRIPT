import { forwardRef } from 'react'
import styles from '@/styles/EventMarker.module.css'
import type { TimelineEvent } from '@/types'

interface Props {
  event: TimelineEvent
  onClick: () => void
  isActive: boolean
}

const EventMarker = forwardRef<HTMLButtonElement, Props>(
  ({ event, onClick, isActive }, ref) => {
    return (
      <button
        ref={ref}
        className={styles.marker}
        onClick={onClick}
        aria-current={isActive ? 'true' : undefined}
        aria-label={`Event ${event.year}: ${event.title}`}
      >
        <span className={styles.dot} aria-hidden="true" />
        <span className={styles.meta}>
          <span className={styles.year}>{event.year}</span>
          <span className={styles.title}>{event.title}</span>
        </span>
      </button>
    )
  }
)
EventMarker.displayName = 'EventMarker'
export default EventMarker
